﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace TestLinux.Services
{
    public class JwtService
    {
        private readonly string _secret;
        private readonly string _expDate;

        public JwtService(IConfiguration config)
        {
            _secret = config.GetSection("JwtConfig").GetSection("secret").Value;
            _expDate = config.GetSection("JwtConfig").GetSection("expirationInMinutes").Value;
        }

        public string GenerateSecurityToken(EmployeeMaster employee)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, employee.UserId),
                    new Claim(ClaimTypes.Role, employee.Designation),
                    new Claim(ClaimTypes.PostalCode, employee.BranchCode),
                    new Claim(ClaimTypes.GivenName, employee.Role1)
                }),
                Expires = DateTime.UtcNow.AddMinutes(double.Parse(_expDate)),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);

            return tokenHandler.WriteToken(token);

        }

        public string GenerateRequestToken()
        {
            string reqtoken = Guid.NewGuid().ToString();
            DateTime expirationTime = DateTime.UtcNow.AddSeconds(3);
            string tokenWithExpiration = $"{reqtoken}|{expirationTime.Ticks}";
            return tokenWithExpiration;
        }

        public bool ValidateRequestToken(string reqtoken)
        { 
            string[] tokenParts = reqtoken.Split('|');
            if (tokenParts.Length != 2)
            {
                return false;
            }
            string guid = tokenParts[0];
            long expirationTicks;
            if (!long.TryParse(tokenParts[1], out expirationTicks))
            {
                return false;
            }
            DateTime expirationTime = new DateTime(expirationTicks, DateTimeKind.Utc);
            bool isExpired = DateTime.UtcNow > expirationTime;
            return !isExpired;
        }
    }
}
